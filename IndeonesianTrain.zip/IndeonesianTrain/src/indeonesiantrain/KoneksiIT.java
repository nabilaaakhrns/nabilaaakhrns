    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package indeonesiantrain;
//import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class KoneksiIT {
    private static Connection koneksi;

    public static Connection getKoneksi() {
        if (koneksi == null) {
            try{
                String url = "jdbc:mysql://localhost:3306/indonesian_train";
                String username = "root";
                String password = "";
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                koneksi = DriverManager.getConnection(url, username, password);
                System.out.println("Koneksi berhasil");
            } catch (SQLException e) {
                System.out.println("Error");
            }
        }
        return koneksi;
    }
    
    public static void main(String args[]) {
        getKoneksi();
    }
}


//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection koneksi = DriverManager.getConnection("jdbc:mysql://localhost:3306/indonesian_train", "root", "");
//            return koneksi;
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, e);
//            return null;
//        }
